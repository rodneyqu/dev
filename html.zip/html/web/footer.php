	<!-- footer start (Add "light" class to #footer in order to enable light footer) -->
			<!-- ================ -->
			<footer id="footer">

	

				<!-- .subfooter start -->
				<!-- ================ -->
				<div class="subfooter">
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<p>Copyright &copy; <?php echo date('Y'); ?> <a target="_blank" href="https://www.raaz.io">Raaz</a>. All Rights Reserved</p>
							</div>
							<div class="col-md-6">
								<nav class="navbar navbar-default" role="navigation">
									<!-- Toggle get grouped for better mobile display -->
									<div class="navbar-header">
										<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-2">
											<span class="sr-only">Toggle navigation</span>
											<span class="icon-bar"></span>
											<span class="icon-bar"></span>
											<span class="icon-bar"></span>
										</button>
									</div>   
									<div class="collapse navbar-collapse" id="navbar-collapse-2">
										<ul class="nav navbar-nav">
											<li><a href="https://www.raaz.io">Home</a></li>
											<li><a href="https://www.raaz.io/#why"">Why</a></li>
											<li><a href="https://www.raaz.io/#how">How</a></li>
											<li><a href="https://www.raaz.io/about.php#e1">EULA</a></li>
											<li><a href="https://www.raaz.io/about.php#privacy-1">Privacy</a></li>
											<li><a href="https://www.raaz.io/about.php#d1">Disclosure</a></li>
											<li><a href="https://www.raaz.io/uninstall.php">Uninstall</a></li>
										</ul>
									</div>
								</nav>
							</div>
						</div>
					</div>
				</div>
				<!-- .subfooter end -->

			</footer>
			<!-- footer end -->

