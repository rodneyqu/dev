<?php
require_once dirname(dirname(__FILE__)).'/lib/init.php';

function simplest_xml_to_array($xmlstring) {
    return json_decode(json_encode((array) simplexml_load_string($xmlstring)), true);
}
function newsFromBbcRss(){
$url="http://feeds.bbci.co.uk/news/rss.xml";
$ch = curl_init ();   
curl_setopt ( $ch, CURLOPT_URL, $url );
curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
curl_setopt ( $ch, CURLOPT_TIMEOUT, 1 );
$rsp = curl_exec ( $ch );
curl_close($ch);



$arr=simplest_xml_to_array($rsp);
return $arr['channel']['item'];



}

function newsFromGoogleRss(){
$url="http://rss.cnn.com/rss/edition_world.xml";
//echo $url;
$ch = curl_init ();   
curl_setopt ( $ch, CURLOPT_URL, $url );

curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
curl_setopt ( $ch, CURLOPT_TIMEOUT, 1 );
$rsp = curl_exec ( $ch );
curl_close($ch);
$arr=simplest_xml_to_array($rsp);
print_r($rsp);
//return $arr['channel']['item'];
//echo '==';
//print_r($arr);
$tt=file_get_contents($url);
print_r($tt);

}
//newsFromGoogleRss();
//$newsArr=newsFromBbcRss();
//exit();


function getVideoFrom5min(){
$min_lb_api="http://api.5min.com/search/business/videos.json?num_of_videos=2&restrictionRestrict=no_html&height=250&width=320&sort=most_viewed&auto_start=false";
$curl = curl_init($min_lb_api);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$string = curl_exec($curl);
curl_close($curl);
$min_lb_arr = json_decode($string,true);
    return $min_lb_arr;
}
//$min_lb_arr=getVideoFrom5min();
$smarty->assign('min_lb_one',$min_lb_arr['items'][0]['player']['source']);
$smarty->assign('min_lb_two',$min_lb_arr['items'][1]['player']['source']);

$smarty->assign('newsArr', $newsArr);
$smarty->display('index.tpl');
?>
