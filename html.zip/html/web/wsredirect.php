<?php
require_once dirname(dirname(__FILE__))."/lib/init.php";


$ourl = $_GET ['ourl'];
$kwd = $_GET ['kwd'];
$uid = isset($_REQUEST['ssp']) ? str_replace(' ', '+', urldecode($_REQUEST['ssp'])) : '';
$decryptedUID = decrypt($uid, OPERATION, KEY, 0);
$TypeTag = getPV("typetag",$decryptedUID);
$SID = getPV("sid",$decryptedUID );
$sec = "B";
$search = "";
$ip = getOneOfIPArr(get_user_ip());

// call Graphite
$graphiteMsg = "bposite.raazsite.safesearchwsclick";
//callBPOHostedGraphite($graphiteMsg);
$end_start_time = microtime_float();


$sst_url = "http://sstracker.smartclicksystem.com/fpd_out_tracking.php?ptr=RZ&tt=".$TypeTag."&sk=".urlencode($kwd)."&ka=".urlencode($kwd)."&sid=".$SID."&search=".$search."&sec=".$sec."&ip=".$ip;
/*$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $sst_url,
    CURLOPT_USERAGENT => 'SST Tracker'
));*/
// Send the request
//curl_exec($curl);
// Close request to clear up some resources
//curl_close($curl);

if( isset($_GET['debug_url']) && $_GET['debug_url'] == 1 ){
    echo "sst_url: ".$sst_url."<br>";
    die;
}

redirect ( $ourl, false );


function redirect($url, $permanent = false) {
    header ( 'Location: ' . $url, true, $permanent ? 301 : 302 );

    exit ();
}

?>