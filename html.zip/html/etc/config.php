<?php

$cloud_host = '';
$campID = "RZSS";

$defaultType = array(
    'web',
    'img',
    'vid',
    'news',
    'shopping',
    'game'
);
