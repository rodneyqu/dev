<?php
    define ( 'SOURCE_TAG_WWW', 'dss.rockettab.com' );
    define ( 'SOURCE_TAG_SEARCH', 'search' );

    define( 'DEFAULT_TYPE_TAGE', 'dss_19a1' );

    define ( 'LOG', true );

    define ("KEY", "sstweb_string");
    define ("OPERATION", "DECODE");
    define ("PARAM", "uid");
    define ("EXPIRY", 0);
?>
