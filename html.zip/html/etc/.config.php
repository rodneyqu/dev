<?php

$cloud_host = 'https://d2jfeccutohmdx.cloudfront.net';
$campID = "RZSS";

define('MEMCACHE_LOCAL_HOST', '127.0.0.1');
define('MEMCACHE_LOCAL_PORT', '11211');

define('MEMCACHE_HOST', '127.0.0.1');
define('MEMCACHE_PORT', '11211');

$defaultType = array(
    'web',
    'shopping',
    'game'
);
