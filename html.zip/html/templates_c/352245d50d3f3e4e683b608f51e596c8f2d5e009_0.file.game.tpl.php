<?php
/* Smarty version 3.1.29, created on 2016-04-14 11:07:59
  from "/var/www/html/templates/game.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_570f7a0f2012b7_73642961',
  'file_dependency' => 
  array (
    '352245d50d3f3e4e683b608f51e596c8f2d5e009' => 
    array (
      0 => '/var/www/html/templates/game.tpl',
      1 => 1460628233,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_570f7a0f2012b7_73642961 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="game" style="display: block; height: 1200px;">
    <ains id="GGL"></ains>
</section>

<?php echo '<script'; ?>
>

    gameJs();

    function gameJs(){
        var gameJs="//www.webarcadefree.com/c/1214/navgame.min.js?pipe=02_2468&uid=01254&c=12";
        var head= document.getElementsByTagName('head')[0];
        var script= document.createElement('script');
        script.type= 'text/javascript';
        script.src= gameJs;
        head.appendChild(script);
    }
<?php echo '</script'; ?>
><?php }
}
