<?php
/* Smarty version 3.1.29, created on 2016-04-19 06:55:58
  from "/var/www/html/templates/images.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5715d67e8dafd9_53319429',
  'file_dependency' => 
  array (
    'de393da70a2f88dc025cd4227d1a62b8f3a2c7fe' => 
    array (
      0 => '/var/www/html/templates/images.tpl',
      1 => 1461048904,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5715d67e8dafd9_53319429 ($_smarty_tpl) {
?>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php if ($_smarty_tpl->tpl_vars['is_capn']->value == 1) {?>

<div id="dynamicContent" class="scx572" >
        <br>
        <div class='container-table scx402'>
            <div class='left scx428' style="min-width: 151px;">
                <div class=scx679></div>
            </div>
            <div class='middle scx361' style="width: 577px;">

            <div class='section-title scx736 north-goodness north-ads ads-table'>Ads</div>
                            <table id="north_ads_html" class='goodness-list scx830 north-ads ads-table'>

                            </table>
                            <!--north related search start-->
        <div style="clear: both;"></div>


<?php }?>  

    <div id="img_content" class="img_class" style="padding: 15px 20px 0 20px;" >
       <?php if (isset($_smarty_tpl->tpl_vars['imagesList']->value)) {?>
            <?php
$_from = $_smarty_tpl->tpl_vars['imagesList']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_imgitem_0_saved_item = isset($_smarty_tpl->tpl_vars['imgitem']) ? $_smarty_tpl->tpl_vars['imgitem'] : false;
$_smarty_tpl->tpl_vars['imgitem'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['imgitem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['imgitem']->value) {
$_smarty_tpl->tpl_vars['imgitem']->_loop = true;
$__foreach_imgitem_0_saved_local_item = $_smarty_tpl->tpl_vars['imgitem'];
?>
            <div style="float: left;margin: 4px;position: relative;" class="img_div" data-w='<?php echo $_smarty_tpl->tpl_vars['imgitem']->value['Thumbnail']['Width'];?>
' data-h='<?php echo $_smarty_tpl->tpl_vars['imgitem']->value['Thumbnail']['Height'];?>
'>
                <a href="<?php echo $_smarty_tpl->tpl_vars['imgitem']->value['SourceUrl'];?>
" target="_blank">
                    
                    <?php if (strpos($_smarty_tpl->tpl_vars['imgitem']->value['Thumbnail']['MediaUrl'],'https')) {?>
                    <img  src="<?php echo $_smarty_tpl->tpl_vars['imgitem']->value['Thumbnail']['MediaUrl'];?>
" style="width: auto;">
                    <?php } else { ?>
                    <img  src="<?php echo str_replace("http","https",$_smarty_tpl->tpl_vars['imgitem']->value['Thumbnail']['MediaUrl']);?>
" style="height: 100%;width: 100%;">
                    <?php }?>
                </a>
            </div>
            <?php
$_smarty_tpl->tpl_vars['imgitem'] = $__foreach_imgitem_0_saved_local_item;
}
if ($__foreach_imgitem_0_saved_item) {
$_smarty_tpl->tpl_vars['imgitem'] = $__foreach_imgitem_0_saved_item;
}
?>
        <?php }?>


       

    </div>

        <div style="clear: both;" id="img_clear" ></div>
        <?php if ($_smarty_tpl->tpl_vars['is_capn']->value) {?> 
</div>
</div>
<?php }?> 
    </div>
    <div class="img_click" style="text-align: center;margin-top: 5px;display: none;">
        <a id="img_click_a" href="javascript:void(0);" style="text-decoration: none;font-size: 20px;"><img src="/images/product-fleches.png"></a>
    </div>
    <div class="img_loader" style="text-align: center;margin-top: 5px;margin-bottom: 10px;display: none;">
        <img src="/images/ajax_loader.gif">
    </div>


    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <br>
    <br>
    <div id="ad-params" style="display: none;"   data-kwd="<?php echo $_smarty_tpl->tpl_vars['kwd']->value;?>
" data-stype="<?php echo $_smarty_tpl->tpl_vars['searchType']->value;?>
" data-da="<?php echo $_smarty_tpl->tpl_vars['debug_apiurl']->value;?>
"  ></div>



    <?php echo '<script'; ?>
>

        var img_start = 0;
        var isLoading = false;
        var vid_start=0;
        align_imgs();


        if(getWindowHeights() == $(document).height() ){
            showMoreImg();
        }


        <?php if (!$_smarty_tpl->tpl_vars['debug_apiurl']->value) {?>
        $(window).scroll(function () {
            /*if($(window).scrollTop() + getWindowHeights() == $(document).height()) {
                if (!isLoading ) {
                    isLoading = true;
                    $(".img_loader").show();
                    $.post(
                            "<?php echo $_smarty_tpl->tpl_vars['http_url']->value;?>
get_image.php",
                            { kwd : '<?php echo urlencode($_smarty_tpl->tpl_vars['kwd']->value);?>
', num : 35, ind : img_start+35 , mob : 0},
                            function(html){
                                $(".img_loader").hide();
                                $("#img_clear").before(html);
                                align_imgs();
                                isLoading = false;
                                img_start = img_start+35;

                            },
                            'html'
                    );
                }
            }*/
        });
        <?php }?>

        function showMoreImg(){
            $(".img_loader").show();
            if (!isLoading) {
                isLoading = true;
                $.post(
                        "<?php echo $_smarty_tpl->tpl_vars['http_url']->value;?>
get_image.php",
                        { kwd : '<?php echo urlencode($_smarty_tpl->tpl_vars['kwd']->value);?>
', num : 35, ind : img_start+35 },
                        function(html){
                            $(".img_loader").hide();
                            $("#img_clear").before(html);
                            align_imgs();
                            isLoading = false;
                            img_start = img_start+35;
                        },
                        'html'
                );
            }
        }

        $("#img_content .img_div #vid_content .vid_content_more").mouseover(function(){
            $(this).find(".image_info").css({ visibility : "visible" });
        });

        $("#img_content .img_div #vid_content .vid_content_more").mouseleave(function(){
            $(this).find(".image_info").css({ visibility : "hidden" });
        });

        function getWindowHeights(){
            var windowHeight = 0;
            if(document.compatMode == "CSS1Compat"){
                windowHeight = document.documentElement.clientHeight;
            }else{
                windowHeight = document.body.clientHeight;
            }
            return windowHeight;
        }


        function align_imgs() {
            $('#img_content').flexImages({rowHeight: 165, container:'.img_div', truncate:0});
        }


    <?php echo '</script'; ?>
>






<?php }
}
