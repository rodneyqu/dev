<?php
/* Smarty version 3.1.29, created on 2016-04-25 10:43:27
  from "/var/www/html/templates/index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571df4cf4e9432_78031103',
  'file_dependency' => 
  array (
    'dbe41f95582903cc2abd53f827507304e4239b20' => 
    array (
      0 => '/var/www/html/templates/index.tpl',
      1 => 1461581004,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_571df4cf4e9432_78031103 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0, maximum-scale=1.0,target-densitydpi=medium-dpi, user-scalable=no"/>
    <title>Coofinder</title>
    <meta name="description" content="Coofinder"/>
    <meta name="keywords" content=""/>
    <meta name="author" content="Coofinder"/>
    <link href="/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="/css/theme.min.css" rel="stylesheet"/>
    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="/js/html5shiv.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/js/respond.min.js"><?php echo '</script'; ?>
><![endif]-->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./images/logo_144.png"/>
    <link rel="shortcut icon" href="./images/favicon.ico"/>
    <style type="text/css">
.cate{
float: left;
width:300px;
}
.clearfix:after {
            content: ".";
            display: block;
            height: 0;
            overflow: hidden;
            zoom: 1;
            clear: both;
        }
       
        .results {
            position: relative;
            margin-left: 15px;
            float: left;
            width: 79%;
        }
        
        .vg {
            width: 235.4px;
            height: 134.51px;
            margin-right: 0!important;
            margin-bottom: 0!important;
            border: none!important;
            height: 155px;
            width: 255px;
            display:inline-block;
        }
        .pos-bx {
            position: relative;
            height: 100%;
            width: 100%;
            overflow: hidden;
        }
        ol, ul{
            list-style: none;
        }


        .vr {
            float: left;
            vertical-align: top;
            position: relative;

        }
        .fill {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            min-height: 160px;
            min-width: 240px;
        }
        .res .thm {
            position: relative;
        }
        .res {
            font-family: "Helvetica Neue",Helvetica,Arial;
            display: inline-block;
            text-decoration: none;
            cursor: pointer;
            background-color: #222;

            height: 176px;
            vertical-align: top;
            -webkit-user-select: none;
        }
        .ng {
            height: 230px;
            width: 235.4px;
            margin: 0 8px 20px 0;
            display: inline-block;
        }
        .stack {
            height: 100%;
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
        }
        .inf {
            color: #FFF;
        }
        .bt {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 5px 8px 5px 5px;
        }
        .v-meta {
            background-color: #F1F1F1;
            height: 80px;
            padding: 10px;
            min-width: 225px;
            max-width: 305px;
        }
        .bx-bb {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        .v-meta h3 {
            text-decoration: none;
            font-size: 123%;
            color: #222;
            margin-bottom: 3px;
            line-height: 18px;
            max-height: 37px;
            overflow: hidden;
            font-weight:normal;
            margin: 0;
            padding: 0;
            display: block;

        }

        .v-age {
            text-decoration: none;
            color: #777;
            font-size: 93%;
            margin-bottom: -2px;
        }
        .url {
            text-decoration: none;
            color: #1e7d83;
        }
        li{
            margin: 0;
            padding: 0;

        }
        .ta-r {
            text-align: right;
        }
        .inf {
            color: #FFF;
        }
        .play-cont {
            display: inline-block;
            height: 11px;
            margin-right: 2px;
            position: relative;
            top: 1px;
            width: 18px;
        }
        .splay {
            background: transparent;
            border: 8px solid transparent;
            border-width: 4px 8px;
            _border-color: red;
            border-right: none;
            border-left-color: #FFF;
            _filter: chroma(color=red);
            height: 0;
            left: 6px;
            overflow: hidden;
            position: absolute;
            top: 2px;
            width: 0;
        }
        .v-time{font-size: 93%;}

        .ygbt {
            width: 98px;
            _width: 99px;
            font: 400 15px sans-serif;
            color: #FFF;
            cursor: pointer;
            height: 32px;
            border: 0;
            -moz-border-radius: 4px;
            -webkit-border-radius: 4px;
            border-radius: 4px;
            background: #3775DD;
            -webkit-box-shadow: 0 2px #21487f;
            box-shadow: 0 2px #21487f;
            font-weight: normal;
            position: relative;
            -webkit-appearance: none;
            outline: none;
            top :20px;
        }

        .more {
            width: 407.5px;

            clear: both;
            margin: 16px auto 28px!important;
            display: block;
            box-shadow: none;
        }
        .srp-content{
            margin-top: 18px;

        }
        .nav_active{
            color: blue;
            font-weight: bold;
        }
        .nav_no{
            color: #777;
        }
    </style>

</head>
<body class="home-template">
<header class="site-header jumbotron">
    <div class="container">
        <div class="row">
            <div class="col-xs-12" style="padding:10px 0 30px 0">
                <img src="./images/logo_home.png">
            </div>
            <div class="col-xs-12">
                <div class="col-xs-12 col-md-3 col-sm-12 col-lg-3" style="width: 367px;
    margin: 0 auto !important;
    float: none !important;">
                <ul class="nav navbar-nav fs_inner">
                <li style="padding-right: 15px;padding-bottom: 5px;"><span class="nav_active htt" form="web" >Web</span></li>
                <li style="padding-right: 15px"> <span form="news" class="htt nav_no" style="">News</span></li>
                <li style="padding-right: 15px"><span  form="game" class="htt nav_no" style="">Game</span></li>
                <li style="padding-right: 15px"><span  form="img" class="htt nav_no" style="">Images</span></li>
                <li style="padding-right: 15px"><span form="vid" class="htt nav_no"style="">Video</span></li>
                <li style="padding-right: 15px"><span form="shopping" class="htt nav_no" style="" >Shopping</span></li>
            </ul>
                </div>
                <form action="/s" method="get" name="form">
                    <div class="col-xs-12 col-md-6 col-sm-12 col-lg-6" style="width:100%;">
                        <div class="input-group input-group-lg">
                            <input type="text" class="form-control" maxlength='100' id="words" name="q"/>
                   <span class="input-group-btn">
                         <a href="javascript:;" id="click"  class="btn btn-default" type="button" ><img src="./images/ic_search_1.png"></a>
                   </span>
                            <input id="ht" type="hidden" name="t" value="web"/>
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                </form>
                <div class="col-xs-12 col-md-3 col-sm-12 col-lg-3">
                </div>

            </div>
        </div>
    </div>
</header>
<div style="margin-left:407px;width: 800px">
    <div class="cate" style="width: 280px;">
        <h4></h4>
        <?php
$_from = $_smarty_tpl->tpl_vars['newsArr']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_value_0_saved_item = isset($_smarty_tpl->tpl_vars['value']) ? $_smarty_tpl->tpl_vars['value'] : false;
$__foreach_value_0_saved_key = isset($_smarty_tpl->tpl_vars['key']) ? $_smarty_tpl->tpl_vars['key'] : false;
$_smarty_tpl->tpl_vars['value'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['key'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['value']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->_loop = true;
$__foreach_value_0_saved_local_item = $_smarty_tpl->tpl_vars['value'];
?>
        <?php if ($_smarty_tpl->tpl_vars['key']->value < 6) {?>
        <p><a href="http://www.coofinder.com/s?q=<?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
&t=news"><?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
</a></p>
        <?php }?>
        <?php
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_0_saved_local_item;
}
if ($__foreach_value_0_saved_item) {
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_0_saved_item;
}
if ($__foreach_value_0_saved_key) {
$_smarty_tpl->tpl_vars['key'] = $__foreach_value_0_saved_key;
}
?>    

    </div>
    <div class="cate" style="width: 280px;">
        <h4></h4>
        <?php
$_from = $_smarty_tpl->tpl_vars['newsArr']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_value_1_saved_item = isset($_smarty_tpl->tpl_vars['value']) ? $_smarty_tpl->tpl_vars['value'] : false;
$__foreach_value_1_saved_key = isset($_smarty_tpl->tpl_vars['key']) ? $_smarty_tpl->tpl_vars['key'] : false;
$_smarty_tpl->tpl_vars['value'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['key'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['value']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->_loop = true;
$__foreach_value_1_saved_local_item = $_smarty_tpl->tpl_vars['value'];
?>
        <?php if ($_smarty_tpl->tpl_vars['key']->value < 6) {?>
        <p><a href="http://www.coofinder.com/s?q=<?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
&t=news"><?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
</a></p>
        <?php }?>
        <?php
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_1_saved_local_item;
}
if ($__foreach_value_1_saved_item) {
$_smarty_tpl->tpl_vars['value'] = $__foreach_value_1_saved_item;
}
if ($__foreach_value_1_saved_key) {
$_smarty_tpl->tpl_vars['key'] = $__foreach_value_1_saved_key;
}
?>    

    </div>
</div>
<div id="catet" style="width: 1200px;margin-left:407px;float: left;">
<div class="cate" style="">
    <h4>Games</h4>
    <section id="game" style="display: block;overflow: hidden;height:190px;">
    <ains id="GGL"></ains>
</section>
<?php echo '<script'; ?>
>

    gameJs();

    function gameJs(){
        var gameJs="//www.webarcadefree.com/c/1214/navgame.min.js?pipe=02_2468&uid=01254&c=8";
        var head= document.getElementsByTagName('head')[0];
        var script= document.createElement('script');
        script.type= 'text/javascript';
        script.src= gameJs;
        head.appendChild(script);
    }

<?php echo '</script'; ?>
>
</div>

<div class="cate" style="width:260px;margin-left: 20px;">
    <h4>Video</h4>
<div class="vid_content_more vr vres">
                    <a href="http://www.coofinder.com/s?q=Ferrari&t=vid" class="ng" title="" data-rurl="#" data="#" target="_blank" style="text-decoration:none;">
                        <div class="pos-bx res vg v-media" data-hvb="#" data-movie="#">
                            <div class="vthm fill">
                                                                <img src="https://i.ytimg.com/vi_webp/E_m-gOmLxLg/sddefault.webp" height="100%" width="100%" class="thm">
                                                                <div class="stack grad">
                                    <div class="bt inf ta-r" id="">
                                        <span class="v-preview"><s></s></span>
                                        <span class="play-cont"><s class="splay"></s></span>
                                        <span class="v-time">13:00:00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </a>
                </div>
</div>

<div class="cate" style="width: 500px">
    <h4>Shopping</h4>
    <div style="width:250px;float: left;"><a href="http://www.coofinder.com/s?q=women&t=shopping"><img width="240px" src="/images/is.jpg"></a></div>
    <div style="float: left;width: 200px;">
    <a href="http://www.coofinder.com/s?q=women&t=shopping">
    <p>Moms Night Out</p>
    <p>Dress up for a night on the town with your girls with fabulous accessories including a Michael Kors rose gold watch, Vince Camuto leather pumps, or Kate Spade’s Walk on Air perfume.&nbsp;&nbsp; <span style="color:#0654ba;font-weight: bold;">Shop now</span></p>
 </a>   </div>
</div>
</div>

</div>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
    <div class="container col-xs-12 col-md-12 col-sm-12 col-lg-12" style="padding-top:2px">
        <div class="row">
            <div class="font-icon-list col-xs-12 col-md-12 col-sm-12 col-lg-12">
                <p style="text-align:center; font-size:12px; color:#555; padding-top:15px">Copyright &copy; 2016 <a
                        href="#" style="color:#2196f3">COOFINDER</a>.All Rights Reserved.</p>
            </div>
        </div>
    </div>
</nav>

<?php echo '<script'; ?>
 src="/js/jquery-1.9.1.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/bootstrap/js/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
$('#click').click(function(){
        $("form").submit();
});
$(document).ready(function(){
    $('.htt').click(function(){

    var form=$(this).attr('form');
    $('.htt').removeClass('nav_active').addClass('nav_no');
    $(this).addClass('nav_active').removeClass('nav_no');
    $('#ht').val(form);
   });
   var in_left=$('#words').offset().left;
   $('#catet').css('margin-left',in_left);   

});
<?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
