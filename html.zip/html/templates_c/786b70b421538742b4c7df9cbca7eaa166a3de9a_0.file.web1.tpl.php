<?php
/* Smarty version 3.1.29, created on 2016-04-14 11:07:17
  from "/var/www/html/templates/web1.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_570f79e505ccd7_19986237',
  'file_dependency' => 
  array (
    '786b70b421538742b4c7df9cbca7eaa166a3de9a' => 
    array (
      0 => '/var/www/html/templates/web1.tpl',
      1 => 1460631314,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_570f79e505ccd7_19986237 ($_smarty_tpl) {
?>
dd344
<?php }
}
