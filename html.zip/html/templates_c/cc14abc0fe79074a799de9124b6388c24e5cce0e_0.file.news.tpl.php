<?php
/* Smarty version 3.1.29, created on 2016-04-20 08:34:58
  from "/var/www/html/templates/news.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57173f326e6461_56032695',
  'file_dependency' => 
  array (
    'cc14abc0fe79074a799de9124b6388c24e5cce0e' => 
    array (
      0 => '/var/www/html/templates/news.tpl',
      1 => 1461141295,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57173f326e6461_56032695 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


    <div id="dynamicContent" class="scx572" >
        <br>
        <div class='container-table scx402'>
            <div class='left scx428' style="min-width: 151px;">
                <div class=scx679></div>
            </div>
            <div class='middle scx361' style="width: 577px;">
                <table id='resultTable' class='resultTable scx831'>
                    <!--north ads start-->
                    <tr id="north-ads">
                        <td class='splink'></td>
                        <td class='splink'>
                            <div class='section-title scx736 north-goodness north-ads ads-table'></div>
                            <table id="north_ads_html" class='goodness-list scx830 north-ads ads-table'>
                               
                            </table>
                            <!--north related search start-->

                            <div class='section-title scx736 north-related'>Related searches for <b><?php echo limit_text($_smarty_tpl->tpl_vars['kwd']->value,7);?>
</b></div>
                            <table class="scx741 north-related nrel">


                            </table>

                            <!--north related search end-->
                            <div class='section-title scx736 webresults' >News Results <?php if (isset($_smarty_tpl->tpl_vars['results_kwd']->value)) {?>for <b><?php echo limit_text($_smarty_tpl->tpl_vars['results_kwd']->value,7);?>
</b><?php }?></div>
                        </td>
                    </tr>
                    <!--north ads end-->

                    <!--news search start-->
                     <?php if (isset($_smarty_tpl->tpl_vars['newsList']->value) && $_smarty_tpl->tpl_vars['newsList']->value) {?>
                    <?php
$_from = $_smarty_tpl->tpl_vars['newsList']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_ritem_0_saved_item = isset($_smarty_tpl->tpl_vars['ritem']) ? $_smarty_tpl->tpl_vars['ritem'] : false;
$_smarty_tpl->tpl_vars['ritem'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['ritem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['ritem']->value) {
$_smarty_tpl->tpl_vars['ritem']->_loop = true;
$__foreach_ritem_0_saved_local_item = $_smarty_tpl->tpl_vars['ritem'];
?>
                    <tr id='trFor0' initialRank='0'>
                        <td class='position'></td>
                        <td>
                            <div class='scx449 search-result'><a class='activeLink' href='<?php echo $_smarty_tpl->tpl_vars['ritem']->value['Url'];?>
' target='_blank' style="font-size: 16px;"><?php echo $_smarty_tpl->tpl_vars['ritem']->value['Title'];?>
</a>
                                <div class=scx372 id='img-wrapper'></div><br />
                                <span class='url scx232' style='width: 500px'><?php echo $_smarty_tpl->tpl_vars['ritem']->value['Source'];?>
&nbsp;</span><br><span style="font-size:13px;"><?php echo $_smarty_tpl->tpl_vars['ritem']->value['Description'];?>
</span>
                            </div>
                        </td>
                    </tr>
                    <?php
$_smarty_tpl->tpl_vars['ritem'] = $__foreach_ritem_0_saved_local_item;
}
if ($__foreach_ritem_0_saved_item) {
$_smarty_tpl->tpl_vars['ritem'] = $__foreach_ritem_0_saved_item;
}
?>
                    <?php }?>

                    

                        <tr>
                            <td class='splink'></td>
                            <td class='splink'>
                                <div class='section-title scx736 south-goodness south-ads'></div>
                                <table id="south_ads_html" class='goodness-list scx830 south-ads ads-table'>

                                   
                                </table>
                                <!--south related search start-->

                                <div class='section-title scx736 north-related'>Related searches for <b><?php echo limit_text($_smarty_tpl->tpl_vars['kwd']->value,7);?>
</b></div>
                                <table class="scx741 north-related nrel">


                                </table>
                               
                                <!--south related search end-->
                            </td>
                        </tr>
                </table>
                <div class='scx479 pagination_html' style='margin: 15px 0 20px 5px; text-align: center'>
                  

                </div>
                <?php echo '<script'; ?>
 async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"><?php echo '</script'; ?>
>
<!-- coofinder_728x90 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-3456478881457138"
     data-ad-slot="6179530408"></ins>
<?php echo '<script'; ?>
>
(adsbygoogle = window.adsbygoogle || []).push({});
<?php echo '</script'; ?>
>
                
            </div>
            <div class='right scx273' <?php if ($_smarty_tpl->tpl_vars['is_capn']->value) {?>style="display: none;"<?php }?>>
                <div id='right-content' class='right-content scx326'>
                    <div  class=scx843>
                        <div class='section-title scx736 east-goodness right-ads'></div>
                        <section id="advertiseWeb">
             <ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-3456478881457138"
     data-ad-slot="1749330801"></ins>
<?php echo '<script'; ?>
>
(adsbygoogle = window.adsbygoogle || []).push({});
<?php echo '</script'; ?>
>
        </section>
                        <table id="right_ads_html" class="goodness-list scx830   ads-table" >


                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <br>
    <br>
    <div id="ad-params" style="display: none;"   data-kwd="<?php echo $_smarty_tpl->tpl_vars['kwd']->value;?>
" data-stype="<?php echo $_smarty_tpl->tpl_vars['searchType']->value;?>
" data-da="<?php echo $_smarty_tpl->tpl_vars['debug_apiurl']->value;?>
"  ></div>






<?php }
}
