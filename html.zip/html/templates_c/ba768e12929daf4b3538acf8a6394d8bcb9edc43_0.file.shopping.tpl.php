<?php
/* Smarty version 3.1.29, created on 2016-04-20 08:30:37
  from "/var/www/html/templates/shopping.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57173e2d1329f8_61459024',
  'file_dependency' => 
  array (
    'ba768e12929daf4b3538acf8a6394d8bcb9edc43' => 
    array (
      0 => '/var/www/html/templates/shopping.tpl',
      1 => 1461140753,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57173e2d1329f8_61459024 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<style type="text/css">
.content{
	margin: 0 auto;
	height: auto;
	background-color: white;
}
#header{
	width:1280px;
	padding: 25px 0 25px 0;
	margin: 0 auto;
	backgroud:white
}
#header a img{margin-left:75px;}
#header .search-div {margin-left: 400px;}
.right_siderbar{
	width: 18%;
	float: left;
	display:inline;
	margin-top: -40px;
	margin-left:-19px;

}
.nav .navbar-nav{
margin-left:71px;
}
.nav .navbar-nav li{
	margin-left: 5px;
}
#adBlock{
width:300px;
}
#header .search-div{
	float: right;
	width:45%;
	margin-right: 27px;
}
<?php if ($_smarty_tpl->tpl_vars['is_capn']->value != 1) {?> 
.products_shopping{
width: 79%;
height:auto;
display: inline;
float: left;
padding-top: 10px;
margin-left: 17px;

}
<?php }
if ($_smarty_tpl->tpl_vars['is_capn']->value == 1) {?> 
.products_shopping{
width: 100%;
height:auto;
display: inline;
float: left;
padding-top: 10px;


}
<?php }?>
.products_shopping_12{
	width: 180px;
	height:225px;
	margin:0 0 0 20px;
	float: left;
	text-align:center;
}
.products_title a{
	color:#666666;
}
.products_price a{
	color:#0b328d;

}
.products_shopping_siderbar{
width: 300px;
height:auto;
display: inline;
float: left;
padding-top: 10px;
padding-left:40px;

}
.products_shopping_12_siderbar{
	width: 200px;
	height:200px;
	
}
.products_title_siderbar{
	
	background-color:white;
	
	margin-top: 20px;
	
}
.products_title_siderbar a{
	color:#666666;
	 text-align:center;
  vertical-align:middle;
  text-decoration:none;
	
}
.products_price_siderbar {
	 text-align:center;
  vertical-align:middle;
  text-decoration:none;
	float: right;

}
.products_price_siderbar a{
	color:#0b328d;
	text-decoration:none;
	float: right;

}
.paging{

}
.img_shopping{ 
border:1px solid white;
width: 180px;
  position:relative;
  display:table-cell;
  text-align:center;
  vertical-align:middle;

}
.img_shopping_siderbar{
border:1px solid white;
width: 280px;
  position:relative;
  display:table-cell;
  text-align:left;
  vertical-align:middle;
  float: left;
  margin:0 0 5px 0;

}
.new_relatedSearch_title {
		font-size:12px;
		color:#2200c1;
		margin:17px 0 8px 14px;


	}
	.new_related_list {
		background-color:white;
		line-height:18px;
		width:auto;
		padding-top:10px;
		padding: 10px;
		
	}
	.new_related_list li{
		margin-bottom:5px;
		list-style:none;
	}
	.new_related_list li a{
		color:#2200c1;
		text-decoration:none;
		font-size:13px;
		font-family: arial,sans-serif;
	}
	.bottom_lab a{
		color:#666666;
		width:150px;
		font-size: 14px;
		float: left;
		padding: 10px 20px 10px 5px;
		margin-left:30px;

	}
	
#header a img {
    margin-left: 75px;
    width: 200px;
    height: 37px;
}

#header {
    width: 1280px;
    padding: 25px 0 25px 0;
    margin: 0 auto;
    border-top: 0;
    background: white;
}

#header .search-div {
    float: right;
    width: 44%;
    margin-right: 0px;
}

#header .text-search {
    height: 30px;
    width: 80%;
    max-width: 650px;
    padding: 3px 4px 3px 10px;
    font-size: 15px;
    color: dimgrey;
}

#header .search-btn {
    background: url("images/new_search-icon.png") no-repeat center;
    background-color: #0b328d;
    width: 37px;
    height: 30px;
    vertical-align: middle;
    border: 0 solid #0b328d;
    position: relative;
    top: -2px;
}

.products_price a {
    color: #0b328d;
    font-weight: bold;
}

.products_shopping_12 {
    width: 180px;
    height: 236px;
    margin: 0 0 0 20px;
    float: left;
    text-align: center;
}

.products_title a{
    margin:2px;
    text-decoration:none;
}

.products_title_b a {
    font-size: 12px;
    text-decoration:none;
	color:dimgrey;
}


.nav .navbar-nav {
    margin-left: 71px;
}

.nav .navbar-nav li a {
    text-decoration: none;
    padding: 15px 0px;
    color: white;
    font-size: 14px;
    line-height: 50px;
    font-weight: bold;
}	
.hdr1{font-size: 18px;    font-weight: normal; color:dimgrey }


.products_price a {
    color: #0b328d;
    font-weight: bold;
    text-decoration:none;
    font-size: 14px;
}

#lb_top {width: 766px;}

       .vg {
            width: 235.4px;
            height: 134.51px;
            margin-right: 0!important;
            margin-bottom: 0!important;
            border: none!important;
            height: 155px;
            width: 255px;
            display:inline-block;
        }
        .pos-bx {
            position: relative;
            height: 100%;
            width: 100%;
            overflow: hidden;
        }

.ng {
            height: 230px;
            width: 235.4px;
            margin: 0 8px 20px 0;
            display: inline-block;
        }
        .stack {
            height: 100%;
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
        }
        .inf {
            color: #FFF;
        }
        .bt {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 5px 8px 5px 5px;
        }
        .v-meta {
            background-color: #F1F1F1;
            height: 80px;
            padding: 10px;
            min-width: 225px;
            max-width: 305px;
        }
        .bx-bb {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        .v-meta h3 {
            text-decoration: none;
            font-size: 123%;
            color: #777;
            margin-bottom: 3px;
            line-height: 18px;
            max-height: 37px;
            overflow: hidden;
            font-weight:normal;
            margin: 0;
            padding: 0;
            display: block;

        }

        .v-age {
            text-decoration: none;
            color: green;
            font-size: 93%;
            font-weight: bold;
            margin-bottom: -2px;
        }
        .vr {
            float: left;
            vertical-align: top;
            position: relative;

        }
        .res .thm {
            position: relative;
        }
        .res {
            font-family: "Helvetica Neue",Helvetica,Arial;
            display: inline-block;
            text-decoration: none;
            cursor: pointer;
            background-color: #222;

            height: 160px;
            vertical-align: top;
            -webkit-user-select: none;
        }

</style>

<div class="content">
    <div style="font-size:18px;font-weight:normal;margin-left:20px;padding-top:20px;color:dimgrey;">Search Results</div>
	<div style="clear:both;"></div>
	<div class="products_shopping" >
    <h1 id="noShoppingResults"></h1>
<style>
.con-rst {
    margin: 0 -45px 30px 0;
    float: left;
    height: 300px;
    width: 17%;
    min-width: 269px;
    vertical-align: top;
    position: relative;
}
.con-img {
    width: 200px;
    height: 200px;
    z-index: 1;
    border: 1px solid #ddd;
    background: #FFF;
    position: relative;

}
.con-img img, .veryspecific .con-img img {
    max-width: 100%;
    max-height: 100%;
    vertical-align: middle;
    text-align: center;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
}
.con-cont {
    margin-left: 0;
    width: 200px;
    padding-top: 15px;
    text-align: left;
}
.con-results-tiles h3.ittl {
    margin-bottom: 5px;
}
.ittl {
    color: #0654ba;
    line-height: 1.45;
    font-weight: normal;
    font-size: 16px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    margin-bottom: 10px;
}

.con-results-tiles .ittl a.vip, .con-results-tiles .prc, .con-results-tiles .binpr {
    font-size: 14px;
}
.con-resultset {
    width: 100%;
    width: 100%\9;
    margin: 0;
    padding: 15px;
    list-style: none;
    text-align: center;
}
.clearfix:before, .clearfix:after {
    display: table;
    content: " ";
}
</style>
<ul class="con-resultset clearfix">
<?php
$_from = $_smarty_tpl->tpl_vars['shoppingList']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_v_0_saved_item = isset($_smarty_tpl->tpl_vars['v']) ? $_smarty_tpl->tpl_vars['v'] : false;
$__foreach_v_0_saved_key = isset($_smarty_tpl->tpl_vars['k']) ? $_smarty_tpl->tpl_vars['k'] : false;
$_smarty_tpl->tpl_vars['v'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['k'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['v']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->_loop = true;
$__foreach_v_0_saved_local_item = $_smarty_tpl->tpl_vars['v'];
?>

<li class="con-rst ">
<div class="con-rst-inn">
<div class="con-img">
<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['clickurl'];?>
" class="img">
<img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['image'];?>
" class="img" alt="">
</a>
</div>
<div class="con-cont">
<h3 class="ittl">
<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['clickurl'];?>
" class="vip" title="<?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</a></h3>
<div class="ItmProp li">
<div class="prc">
<span class="binprccon">
<span class="binpr">
<b><span class="intlPrUnit">US</span><?php echo $_smarty_tpl->tpl_vars['v']->value['price'];?>
</b>
</span><span class="bin">Buy It Now</span></span></div><div class="hts-txt" data-tier="2"><span class="hts-sp"></span></div></div></div></div></li>
<?php
$_smarty_tpl->tpl_vars['v'] = $__foreach_v_0_saved_local_item;
}
if ($__foreach_v_0_saved_item) {
$_smarty_tpl->tpl_vars['v'] = $__foreach_v_0_saved_item;
}
if ($__foreach_v_0_saved_key) {
$_smarty_tpl->tpl_vars['k'] = $__foreach_v_0_saved_key;
}
?>
</ul>
	<div style="clear:both;" id="vid_clear"></div>
	<div class="img_loader" style="text-align: center;margin-top: 5px;margin-bottom: 10px;clear:both;display: none;">
        <img src="/images/ajax_loader.gif">
    </div>
    <div style="clear: both;"  ></div>

	 <div class='section-title scx736 north-goodness north-ads ads-table'>Ads</div>
	 <div class="shopping_north_ads img_class" style="padding: 10px 0 10px;width:102%;">

         <div class="scx600" style="font-size: 14px;height:200px;width: 32%;float: left;"><p style="margin: 0 0 2px 0;"><a class="activeLink" href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3Dc17cKcy43vaDh6GFs49zFDUs9lNGu3mUTP9Ro6hzFX7OJl%2FFPPJ5ZbLLTaNwYNuyVtAhwaPWWXDFYxRJkqIIzvXB%2Bomc7LLqNH0rkfnI16fTcEYQkW9lkUnkzTaSPJlPuPgdg96MGnQRMxPV0UUPae1jW1Ku7du14y996%2FDcLNlCwJDA7DXyA9FzUsjQZD3JWZ%2FrxBSz%2FIsLH%2Fzzy05XXeb6Q8DEyGtb373hLv8wSqARR2GwgXlLP7Y9KyXyYhuBHLm5XrJjOlorLd7in3E5julyadrq2EYZmuh7vLaDlUsa5KYR1ThWL%2BnFWgB5xYTqwK2Clx2RS6vKHOU9v1wLvxK6swpfkddiCTLKonmTScDEE%2FRBvGod%2F70p%2FTZanAelPO71OpNssCOcSwfvoGQ9wKnJ2iPBhEqE3LuaW9w7JDZUEYCfVnJZoSTRXL5gFYrZBlaBsZ9BKM%2Bfd4SMX9wCWjoA1bnGOGzvSmTTdP1WXkeI6Lrvdb%2FbTFCjCR2mcsRrz6MO4M0RlOWjWGdiCDshPFdsqtLNtEnYjKPn7T7WjcxLN4hlGORTvDLS2LrwQ%2FIdeRJlpWmGrHUN7KgcR0RC9hBWyQ7ChrVxlXVSAVSKRGSXfwsvd5MrDCNnrgJpztWydRAzqiCvKDcBPy5Hv1K937Ap7Y77%2BDu67lcwGCjbc2Pn&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank"><b>Apple</b> <b>Watch</b></a></p><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3Dc17cKcy43vaDh6GFs49zFDUs9lNGu3mUTP9Ro6hzFX7OJl%2FFPPJ5ZbLLTaNwYNuyVtAhwaPWWXDFYxRJkqIIzvXB%2Bomc7LLqNH0rkfnI16fTcEYQkW9lkUnkzTaSPJlPuPgdg96MGnQRMxPV0UUPae1jW1Ku7du14y996%2FDcLNlCwJDA7DXyA9FzUsjQZD3JWZ%2FrxBSz%2FIsLH%2Fzzy05XXeb6Q8DEyGtb373hLv8wSqARR2GwgXlLP7Y9KyXyYhuBHLm5XrJjOlorLd7in3E5julyadrq2EYZmuh7vLaDlUsa5KYR1ThWL%2BnFWgB5xYTqwK2Clx2RS6vKHOU9v1wLvxK6swpfkddiCTLKonmTScDEE%2FRBvGod%2F70p%2FTZanAelPO71OpNssCOcSwfvoGQ9wKnJ2iPBhEqE3LuaW9w7JDZUEYCfVnJZoSTRXL5gFYrZBlaBsZ9BKM%2Bfd4SMX9wCWjoA1bnGOGzvSmTTdP1WXkeI6Lrvdb%2FbTFCjCR2mcsRrz6MO4M0RlOWjWGdiCDshPFdsqtLNtEnYjKPn7T7WjcxLN4hlGORTvDLS2LrwQ%2FIdeRJlpWmGrHUN7KgcR0RC9hBWyQ7ChrVxlXVSAVSKRGSXfwsvd5MrDCNnrgJpztWydRAzqiCvKDcBPy5Hv1K937Ap7Y77%2BDu67lcwGCjbc2Pn&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" style=" text-decoration: none;position:relative;left:1px;"><span class="url scx847">www.apple.com/watch</span></a><p style="margin: 0;">You. At a glance. Learn more and shop now.</p><table class="scx741"><tbody><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D1463LXdu8g6Oz7s3ExwZvmIJPDdMliOlRCKwjYb8PyBaDVyW2uca%2FjtG9Bk3ZrfTYtlszwWTOvzhR0P5tNa0RwpBuwU1HFDNvhuIVkDhtVd90PoP6kJplfjHdgDChtwV1f9z%2FsmU2P3HmlODBvL4lGDVnOAWks94XtVveRBnjuxgiqLV0MFdOoajft%2B5neuzvJsBHxTt6lQjo0f3%2BFEeiurSs8cRcOAyS9u7C4%2F95i6xT6%2BH7vthhEHbrReSSgokrjkPbLUhWobDAG7ioJymZCyjdAezlaoHZhGOR5GsQYY71gXLcbiwzNoCXyePsp80eaF0XLR2ZA4KrL4qLBltRiGtd9moT0RfafaeVdIQpWE4gncMv1MFA1nqjd8mY%2BgjBX%2FnStJq3rdRDltcPLpC7qE6jgCA5dyxSFzxNpRi%2F2pnbS%2FiBDSFnx5nTV4%2F13VA0Pnuohu37b%2BMCWIcZq6Ip4YRla5IW%2FWTSRBNWNqpVDlAc%2BeLwLVPUSMhLpzKxYiHFxSzQn9Ag7vbKo4FOxe0Zpq0hMvCSH8jPpOpUnAZv0Ik7zLKA8ICqQv0P4g1QoMS415ORFlGtOseZU7qEl7lwSkSw5Gk7ItMv%2F77uMFChvjLhQ&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">Buy now</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3Dd338GRDFPVzfkE%2BzNfTlD%2B45a9xjBLLICVzXNWMJCigP8d%2Fb6xHox4KaHmuyUzweGUxxgOpfqaIWgE4%2FK9DTjldI%2B6Xr1KUEPurm5lIQUWHXkg5rNWWr1qPRJP4p7fZN7gLSIdXkHiWtp5cB2ZI00vOisnmSYMzzI8sFfp9mloE8r5BEshjlg1S47M3Gur09HA5NSmHYA2GaaMBt4ILHJxXOjDsWdt%2FKwyF13E7HIjqUkVZIh0vloUG8itk24ideMgnYgVHev7qv%2FXTO94JXF1BM5LEV4nrbudgtQUEeopNb020MMnt3LstOvvpK5NyxcFrHQPFx0nuxXrhCPoX66v%2F7G4zQVXNyE76%2FSNN5navnurJnpQeiVvc%2BHe%2F02PHKrsM2IEHmRWYDp4eOmN%2FKWFOZVFDOUfJikrXBB8XsXHoNrgYNUI8mvm7TzcxR183dJyzNU%2FBr3DLdFnUTeMKBCLCy6a8htdftC62WEqwFJ%2Fk5w6FD4FhXToHEFCxm2zy043kZ%2Fz7meKFR34AZmEC%2FX2%2Bl2bGxQR6UJOYtwAs5rBjRTpf0zszPdNNciGozIOgxwoDpykZe1uaDxbHylrS4%2FakDWm0TC7L9EEg75%2Bdmgb5lNw&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank"><b>Watch</b> Bands</a></td></tr><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D3a50aWFCi6S1c3m1Tl9%2BtmP3KA4wvxdsXlMamtdixBatv4Zdinj%2FssmhsGlYHvnjCkxIMKDA4v2jf66YvYLXwBHEhd7TIiw38jFPTv9PIuYNscSz%2FSxOvo9uBK%2FTr8edM9WyeXWrs%2BA9CUAYZoV%2FWvouZb1ZuFZe%2B55P1cSPz8M25xhCuc95RUF8YQOFoKn0JF2MNSD0%2B3LmFn9W%2B%2FVcKXnmA2aDufNOcASdZJb06Ls2%2FgHiK7Tff88kvvLmV%2BatO%2B%2BulimHU283h6pR%2BkgNA8wPJuDnQRfm7rzRa%2FGLFR9DLkGxDcxvcXEFReEtFGfG3xn16uCdxD4x12wwlj80YbepSREXAgZWYizXLbYMwRlIEg5s3hEkZJKWK8CtEjE1fl%2BIvtjrCJEyDKfWqMuGQHiyUDnSsVnLfBVz4cJTbvHuCHo88RQ8oJrN8F%2BXO2lGJC4fHgG4zOvWTODg2J51P0jA3XL5WnHyOdfN%2FjoXzLsDvHSDxfzyHCIN6HXN3TxUCaK5CZjcIKTYPgeD1iHx%2BdfKqsppBy1rihKCp4hPS9dX7o4X3wu3%2F%2FHiz3SQxlcmnRPX6lrzqBqU1bHE7BkoT6RiGRCS2pS%2Fjv6cwIpGfMNhQg&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">Fitness</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3De42dJ6aULfQA%2Fby2FOLFynJ6gP1ZVieQXtHzJmpwPkVnS5Y8h7V%2BB2Gwtzq3KoQQPK1qJeY5AvO7iHL9QECL2eI6lGmDqRAJA4btfL7Pltc6Tmp%2BI5lwqdlMvr89ZoY%2F4Y3lS7K6vtj90wtx%2F9sBF1yLo0g%2FaiwLI6CCW2HWL1qcpnuAl8n0y9FI5E7jvV52SFzPRVg1gbSp90A%2FS%2FOAwuV9yi7BD69ADQXp2ZiUQ9ADbosjJyiKBeNOSJwVIT4VS6ImlgRlYGI0GnwYmizWFWHzywX9AZd1aZertgKsiVuQhThQGRJ4EXhWxtKBh5mMY8y5Rg9rsSoZ0G0z1TsTVFFn%2BGhNxa1VpdngziBZzYNnOpRy2pWOx4G0u5g4qtDBt1adKVdYDOvC1oIy4zQhK49ZtPotYttSd2D5WlUnOXq4iI%2FmNg2ZDfCxQH7AT49BjCzojTc1L7eB%2BoxNl20Z7fe%2FfgxdJZkVqEOulppP0K3l2pmonopPgrX5Uhijb6aAFpiyPsGZ%2FOhunQCL4klL93hZwoZ9PDzcYGdqPIHSIvxYWKFw4z4ZpxXaxXEKk7nIG4vJOjFsWTVzyt85l70jz6yCjyai99%2BJK1w4dmt4uKykdw&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">Notifications</a></td></tr><tr></tr></tbody></table></div>

         <div class="scx600" style="font-size: 14px;height:200px;width: 32%;float: left;"><p style="margin: 0 0 2px 0;"><a class="activeLink" href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D65e22cstCexgTuuL9h%2Fo8kBiQ51iqPFy487%2Bg8BQJxE6lIZ5KOSUO0VhIAjDjgFWXR9NyxgJW1FzneTKBnqcXxDu6o9dxfESo1XailBuaAzpOX3Tc%2F2IHIf9RUIWhGX%2BL30FouK82vydkx9nPywTzpXURrbCc%2B1sH2oRWO3VbIlojxehs4uftwOaPD9GM5GvH4G9zg%2BPvymDCJbSHi3Vl90P3z4mOhw7hPUbED70gaMh26R9g8whbBoAxk%2ForrnuCRxyxCF8HplpBwvUM2IALWcW6SsIdYQbTM%2B8JxxrNNwdoTnvT6yfJf928MGfjgvYxWvNaLwNyfOd53ddVTdNCVS43yOdpo8pfbiig%2FxRUoYNQfkfjIciWM4%2BG6%2FlTRlJhGDGEuu0PlaxgaKoizHoxz0Vp9S%2FWDjNp1gPT3i%2BsO%2B81pcMZFN3wHMy2hs5rNFErvVNqSWOZtVkwccGrJTVKRltQu8a%2BF72Zszawp8tjbtOrfnMhrjSfNfcUkqm7yG5RwnT10Ma0LFv4r%2BZRDz%2BdSNwl9YcTBTKv0Y3C4BedYCoYY9JgZaS%2BJCUVVCK4M3JqRssFKSU8gPRdB1Uhq77Mr264QM6%2Bp8YiXf4DxMZfIkCDeLWvTAbw34pwN8bOIe5ZCeaB%2Brq3PLXVRs3rvvm1j%2BKzyW3QbzGS6JKVmYnOgRm&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank"><b>Apple</b> <b>Watch</b> at T-Mobile</a></p><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D65e22cstCexgTuuL9h%2Fo8kBiQ51iqPFy487%2Bg8BQJxE6lIZ5KOSUO0VhIAjDjgFWXR9NyxgJW1FzneTKBnqcXxDu6o9dxfESo1XailBuaAzpOX3Tc%2F2IHIf9RUIWhGX%2BL30FouK82vydkx9nPywTzpXURrbCc%2B1sH2oRWO3VbIlojxehs4uftwOaPD9GM5GvH4G9zg%2BPvymDCJbSHi3Vl90P3z4mOhw7hPUbED70gaMh26R9g8whbBoAxk%2ForrnuCRxyxCF8HplpBwvUM2IALWcW6SsIdYQbTM%2B8JxxrNNwdoTnvT6yfJf928MGfjgvYxWvNaLwNyfOd53ddVTdNCVS43yOdpo8pfbiig%2FxRUoYNQfkfjIciWM4%2BG6%2FlTRlJhGDGEuu0PlaxgaKoizHoxz0Vp9S%2FWDjNp1gPT3i%2BsO%2B81pcMZFN3wHMy2hs5rNFErvVNqSWOZtVkwccGrJTVKRltQu8a%2BF72Zszawp8tjbtOrfnMhrjSfNfcUkqm7yG5RwnT10Ma0LFv4r%2BZRDz%2BdSNwl9YcTBTKv0Y3C4BedYCoYY9JgZaS%2BJCUVVCK4M3JqRssFKSU8gPRdB1Uhq77Mr264QM6%2Bp8YiXf4DxMZfIkCDeLWvTAbw34pwN8bOIe5ZCeaB%2Brq3PLXVRs3rvvm1j%2BKzyW3QbzGS6JKVmYnOgRm&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" style=" text-decoration: none;position:relative;left:1px;"><span class="url scx847">T-Mobile.com/Apple-Watch</span></a><p style="margin: 0;">Unlimited talk, text &amp; web on our nationwide network. Learn more.</p><table class="scx741"><tbody><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D09a8sL2NarDoS2SYj2SWhtkSVwmRi2i9ftOUWbQ0XSIxyMNgtQgigUHN3Mx4jdg4rK4bX8iIhnuRhkV0llZPTe3ZV0YX%2FwAtDR1yinbC7Chz%2F20cfMHJu%2BPPAdKJ7yJxezRrXmCkB%2FcXW1NCxDbLnA19a7gdTIVnPIND1%2FEVW598%2B3bp7lDTfiyntB83FuVWFH3yjqqpw3nrAjJ9jnalfNuzbTGFwrj2wQHNFa%2FQD9ON1Hx%2FJ0BXk%2FruCx6ONe7q2IbkhyVN0ufnePCT6PxAY2BzfIG9mINEAA0yjSK7sK9Im0QO04DzUX5JiOjcJWmLJcn%2BcMNha62v0t%2FqeR0lsrdlBjc4v0ofsNx0uAjMRJoYa3faYytopF5xSA62Zlbeik6Th2%2B3zbJaJVg%2FZ1hev7UN%2BcnDpMkdA4%2FeiyzNgBY2cvN0pxZCBNQv0i77P%2FRNXj8cHiLPUEO4yWrOkzuUk7lGklLtWJQis4I8fwlSMtNzaBx46w6WF4kSt8SIqdkLr1vR33XSSC%2FIC02J62%2BKU5x4sTZIe%2Fb%2FtxhFPjQQeGVx1RdRglp8oBrnmNwpTZS%2F4CafhrvF0PWDcwEVQIRg8DU5NgkZVqpcySYAJejJHQEAug&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">iPhone SE</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D21c7V3qlIJNWw196PeM3vSSr08%2FfnxARByD0Xm32UUVANvJ5t2HkPIJd41tjKTvzh9t47fmQz7YcPSMzJV7ALnt2tXDUUvfcqrVqnPg8bUHjnxiD8LQPQOwtW6gEW4%2BPZkvoRK60qVZGNDS8skvAANXS5H05xLVD5JIJIlANfOlQvROGPKT4x%2FkdvnOHcYc1M7Mq9x9ahG57lLMhrX%2FXitUiSTGkSpTwNlOgfDY6FLFYlN0zFYkrsPAvQByi4P%2BoHLfm7bQiDt5%2BAt%2F5lnzRnHJw3u5v4OHSRpPA9oEIWo0s2IDOE6R%2Brmz0O1mgBmB6mWyqeyGVeFGl%2FPncdIXlltwVxQVc2YevnbRPQgc0tEb0VOzrP4Y5TmouVnOMAnB2OGpxCJNJI7jSgAVVSW2SeYx6xFALzivcAlQcuhLf%2FuWCehvzD02R%2F5f5Yv1yD2epBljbP2uSzFV08ZcFueKfroZqeGkF0IPOx6I71a3%2Fscl0Y18pYS2LFqf0MmLrH%2FZtXT%2F%2FulsQRzrlfLbt7r7kJVRT43BMtFkMPB3shs40Y2RX2VCIldY39moRtEiOhWE2p%2Fsbd7Pk7YAOl7aCEBwIxnadG0wPHgesuv038bP1%2B8Y6WA&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">iPad Pro</a></td></tr><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D6295h%2FWsxoj6yWk7cJSlbxTJzMSOMoo9nTUVb7nkUwJYblNuK0vPfbsqbTxTl35xt72Rwsa0wK6vT0m81%2FLJXXbX%2FkIvz3WfhZfuDF0YJKhAxUDyiH%2BpDoi04neDxMaz%2FqbMLsX6I%2BZ%2FGGSY22Es%2B8ckmFXFAOQ7tjPCRpuPy8yTz3tpCCff6%2FBhPMXDL0eyLXB%2BEnXNrDuj8ofOv3V0DYfd2124%2Fu5Ga6MNW5nHOVqHuIKufhjhSjCZYPuJ7i%2BcKRe4NQ5AFO%2FCPG19UBPHSg%2BsE0JnZTEZjXO6vCkB4JQVLXlHeVFIrBYLwMJkHWHvnxfGF2i7HQnEtuzPoq6EL98cIGWiGnXJ8RsOq5AkY4zqp5Miu2E%2Fp9malI5BxsMKlIiyoGFx3j%2FlrSc5e0l%2BO7l6YWRfnNYyUaQaVj6dfdqgPKDw28SLplfuHFYCf2y9wlvkLjBHnXvIor7o7vfdZRaI41E%2B8Bb%2Fzr8nDf6VGd1T2dJ7RQMVzNd0y7TO93Fqso0CTn9H%2Be9tFxk8boIzpTSK5wTyZVWOuympIrifhm2I7AXZMXxAwFTs9FQXBH8pv%2BDxgBTZIm2Tke10na1wQSbphb6fM06ZFMY6kjhwc7HYjg&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">T-Mobile® Network</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D7ddaGeUiJB58xrljnolMxcWsLMd1XCzbRXLfqhz%2BmyUJw2uda7NU0sYC%2B1Kj9u6DNApMvFo%2FmUP8mYSe3fOMQJ4vrhXaNJn6YwtFTwiwanyG3XJmRi5wzpkBv4xBMYP%2FSQwpIHPdHfwMqALtENcFpTnNbCZR8aoSD2wtuuz6qAQqq2OeCgWSBC2mX6RM6RQgC9eqbamwTSx7x7hiK5JhICMO13%2FIbgWQCdTsskKbutPjqHpCzL%2FHlXq7MARR%2FNbLdK11clWataL9%2BoJtz93fQiZtUaqckeN5Pxywaebuwpu35Ng6fb%2FmiEX58h6ZqqHqcc52ZQVONdvU1e3cH2x4kbAJJ1wrZGmKgc0vP%2FpcDa5z%2FYhLfQZQ7THT1NymrFTfxVAjSynomvdjdFi%2FMK%2FRQwbVuG14AXXfXYoQR4Ztwz2fP1nHAViRw%2FxFipGY0Jc%2F6DZU3NwWoP5BB51VZPEU%2F%2Bs3YrPa0norCOGjaERjg%2FYGXkyv5QM60xMEdSISFlKHsIPeXo%2FPw27rqQ4OAhm9jPwiFTgomWOkyzZajev5xj1YLAOokanc%2FHl69ss1bavlafFqM0h1maAUiKbWyATAcSxzC%2BCPD1GkrCY%2FCRwwfTF6nw&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">Find a Store</a></td></tr><tr></tr></tbody></table></div>

         <div class="scx600" style="font-size: 14px;height:200px;width: 32%;float: left;"><p style="margin: 0 0 2px 0;"><a class="activeLink" href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3Da5611mD40wo0QqoAgZElW53yLuE10kp1Uge8dUoKCcE5xOsJb1DUZ9fCHP9vpJB8RG4UnSlzQf8GPzWjZ13%2FqtLpOAV5jCaZuPH9WOEq0bQS6NP02BYxJDzLcY11Uwbd1wcBHqYSFnzre4gnVWtFCHYYLY8WH6IAf0LC0j5z5KipCFCKYPSEHk7ZmBdmFRPZA8I5X7iLU7EYINax1U%2BYi55o9MJqzFMxm5JCii9io0MsY5uonywnWYzLf23TU8EL5hh6S0NWQBgtha%2F7lUB7obcMTxPA50RYMQ%2BTcgMRrJ%2FwTuvXD0y6RoQraaUjYfzcjIFxYy0%2Fy8bHtUxyjEEtJwfjeCykOTLJOGhFsFA%2Fo6darfgL2knceyOAKN2HHw3fB7UX1C7M3qeXCfyP4%2Fxx0DC%2FZam6Sd1KetutPmk7EYnk96QCIL59OgeNB8AHNb3EwKN921xhRlb%2BF0QtK40BEYbUY1jQ8mGbHwfJRCtUavXx%2B1Rilh3r1HEViBbbRSdo4P0k6XjMPlCMlsL8qDzNg2AxlPqlRZ4O3mr0O9h6RyKjupvrf8MM%2FgpxXP8jKHRMbMcCSFqlrHZ78AHy%2BqASZqEmSaVbYQmHj5Y%2FgPq6eXyj%2BRcP38wMINQ%2FOy3SfZr75d4kKW4GXn4x3539HTJH2Ku0jGfupz1V3XkVZtRgl8RI&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">Designer Smartwatches - Designer Watches Engineered by HP.</a></p><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3Da5611mD40wo0QqoAgZElW53yLuE10kp1Uge8dUoKCcE5xOsJb1DUZ9fCHP9vpJB8RG4UnSlzQf8GPzWjZ13%2FqtLpOAV5jCaZuPH9WOEq0bQS6NP02BYxJDzLcY11Uwbd1wcBHqYSFnzre4gnVWtFCHYYLY8WH6IAf0LC0j5z5KipCFCKYPSEHk7ZmBdmFRPZA8I5X7iLU7EYINax1U%2BYi55o9MJqzFMxm5JCii9io0MsY5uonywnWYzLf23TU8EL5hh6S0NWQBgtha%2F7lUB7obcMTxPA50RYMQ%2BTcgMRrJ%2FwTuvXD0y6RoQraaUjYfzcjIFxYy0%2Fy8bHtUxyjEEtJwfjeCykOTLJOGhFsFA%2Fo6darfgL2knceyOAKN2HHw3fB7UX1C7M3qeXCfyP4%2Fxx0DC%2FZam6Sd1KetutPmk7EYnk96QCIL59OgeNB8AHNb3EwKN921xhRlb%2BF0QtK40BEYbUY1jQ8mGbHwfJRCtUavXx%2B1Rilh3r1HEViBbbRSdo4P0k6XjMPlCMlsL8qDzNg2AxlPqlRZ4O3mr0O9h6RyKjupvrf8MM%2FgpxXP8jKHRMbMcCSFqlrHZ78AHy%2BqASZqEmSaVbYQmHj5Y%2FgPq6eXyj%2BRcP38wMINQ%2FOy3SfZr75d4kKW4GXn4x3539HTJH2Ku0jGfupz1V3XkVZtRgl8RI&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" style=" text-decoration: none;position:relative;left:1px;"><span class="url scx847">engineeredby.hp.com</span></a><p style="margin: 0;">Designer Watches Engineered by HP. Smart Meets Style. Shop Today!</p><table class="scx741"><tbody><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D7e93EtKeUKE%2B%2Fwiuq%2B1teKPFTWcM9N22txbk6r00wN4WuR24FS9mnxK8YXF6lRGK9VXQEe7nRpT2cKoJ4GO%2FZn2WPUZDLaM94R9M%2B%2Bxi3JMhTm5L7AFjFscABpYNAMeKSC%2FFraLvpKSGUXl5bBlDAf%2FTMDnvtSY%2Fra88zFbF3VktdqYmfqNjJOZ8XDqfqXHqhKsvzK4IrRKhituRcmgEz6gHzlMOpz4Xc7oNkGtw29soijtuMkbTMShSh%2FwZNudg0GlCcGyjQl4ZWjuN70BsB%2BDv1LEejL415n7yErD928LeaVF4qTiiMHRYVdI1OKx1H8u%2BAGRMavDWJGZ5Vzw6og0%2ByPOQD%2Bg0GUPp2Cf3X3KBK30v2QnccY3up5cOEaw8uqu8vRekT5YeM2CAQ3BMEGqRwsyNQRpcxxFMEJkzXyp6j7LMa6f2qB8Ol1bK43yhdaXodGSe1l6rgGXrpExxgngbupTDHZUMCKaY5479lBVQnjjpyxO8F8rSurFP6HAwn78ZtKfjEay1bY3I6QCwLDMHt9de3YA7NZ7ihZIPS2GF2ra367ObMOIxdfTeXU9%2F%2BhjVXChioQteLV7ZB%2BtpBoJ%2F8EyjxDqee%2BmsvNqBqIpsBA&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">HP® Store Coupons</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3DedcaRqSMeE57ft7pduvTn4JZgi0r2720kesHj9nZh8fLkuUQeLopID81RoIRFkUf3vJouDoLfzJheMebQH%2Bz7Fe1zje%2FQWhnU0ZPJX14t%2FMJh1KCa%2FlRPeJcfWLw7%2FEfVYxFOyNZXafr1hKDvv2pFaBQ0YWiZ4rixhn7Mpu%2BrsCK9WEBGRWCFXrFVKcGGShM6pPOdPuyyDqHhV0hYHCLXA3h7XMg0QBCoeyZexsYwsWIUE3hlqVguvn7KXVNc4O7JOoUaZ3STdTWwr2GRky1sfLamVPM8O7ankM%2FckHVMJT9QvOkOb0T3S99xpO2kVwoyheK0tyqwc5zXtHyIuQ60EHndFDqkXidsRwVoe5yH%2B0jkpDKfeCEWxHtEHRfIzPSFJQJY4%2ByzaVfkhRpgWiyi7v87nTgj%2Bi8jMgMSYZRDfX2H32iDtAKuWeA4qGzymn%2BleCh7z9Nh32MdHFUHFFPE3NFstpFzR6PxGwCggT8Sj5YKJEv8x0l3pS5ItdpqZ9tAMvHHW6WB5bSJUigA6jtrzgG9AkI5WeeEXrJut7EcHTTwTB1eMzqVGHa6JIIx9sBVU8Q7b47q5KCm%2BbjhEF6D%2FNuUUGsMxpW2lFy8HZu%2FMMcNg&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">HP® Spectre x360 2-in-1</a></td></tr><tr><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D4dacMrjF8XwLxa%2FphBuSkJ2jWgLqiVEb4gOnzRDgrtfml%2FbB7DVCzWx9JjDcweidpESlEPzgCrRHb7RcsuVj%2BLIkB37jVS1LYD4aR45%2FfdlfZ2GzFkWin5Nn9zX0lHsGjsqhatlknMOQ9g66IT%2FRsA63j1PCY54zqK6B8r%2FhWdoY3naV3lKeoICCY6Jk1cI5BkYuvswwcyO0LRtx8%2BI28Y26fpycl56wd0rekhcKtyzgGPas4PTjUw4nOX3DvdpuP1B0uG6%2BCqpno%2FfeIyJnCMTEMJZK3OQKDyZBWgbULergmRWDccngZy0kqbvs0CLEsu9ifM1HTmmVc5KxPWL2XjDpSLA2qtgh2nvPG4DvIKZlKX1h2lA%2Bn4PwgrSfmb6hZIBm6wmhfmDP5OpqtrSWtdCdX68GyxUMbAZx%2F7D1Eaq1SPfATF7PayJ94Ojv7SUjaELKj5%2FgwgSu4ln0rewNVc1NSKQU%2FNNbQ8DTwA1N7uNmbWM1IxhBB0DIKMrBuMGTGFakB0MdCpq%2Fj1hQfb6%2FNQbOm4x1nvJr8ER%2FG%2BXbDakwIEgKgjXLAEZPrTsaFtArC391hc2KlwSrSjA2PpK%2BeWNB0KEA1NMMqAMvCx13V7wNkg&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">HP® Accessories</a></td><td style="padding: 0 0 0 5px; height: 7px;width:30%"><a href="/redirect.php?url=http%3A%2F%2Fclk.raaz.io%2F%3Fuid%3D6a2e4yUyUF8LnriSV9X0DnEEfinS%2FpbWqeCCc3EBxzZwCKm6yxS6OssfxoSnORJqz3b8M4nljuuhdNagL17V8WMIvlrrwdbpwZ6iHBVC9C8y%2FSeffGBHY86n85iDK9VhBuycLkwwWl7k5zlaxIhc68RlBiOL1za6TZm25K8ZpkKTZJdYeyfWM8GgS8e8GT4UBNZeWK6ksW5JlAq4XK6a%2BZD9AOtFILcvJsVDgM2Q1LrUoBjpDNCRiBzzADOCgxwr%2FNkOvSDZxbVKk9RFiF%2FBkpzpmsPkn8KaOSfVCI2YRKHQnnCdU0O06isbNzTIhqDQqqMwOCRzkxDUnCkHfMs2Kei89o11m57tzMFLJx0ICtLI5ECWAX5F53dN%2FvvXwPcewUi38CooEYi9%2Bl68S7hbgtsCOIkGEUSnCBEa0ciLj6IxiSH8DYcm5zjLji1AmvIhhGCzxdRKg2oKm5jxPVcEwOZ%2FJ1LyHj%2BXQyYfSgUb%2FWGh6h6ZDeaX2Hziz6E%2FkFIqREfAPVB72FywJK9ORCXcwXWBe1Os6KNpLWq6bhcMBCD0B31xjGHRxvwVCPCi%2B9M6U9nqEHSV9w0e1y3sD60xIEvkJ%2FSkZ4Et85XIcMjkTQoSbA&amp;SID=87c8ac9096d48666600f6851492246a8&amp;tt=dss_19a1&amp;kwd=apple watch&amp;cid=00737069676f745f786d6cA00A68454&amp;m=2&amp;eui=&amp;page=1&amp;ssp=f4dfCybwhDmXX4cPdKsxr3VN8keZVL6YPTzNKjo8uwTHzyhlfrJawGPSF9Zq0LWw%2BlNFq5ddYPmbet0qzEBlY1Ie%2FfCCPClCpPvjRN0OapIHOHzOicI5j3%2BEzKZbEz9moPTsVaA%2FoxYvj2itzz1ZJneFzp56L%2Bg" target="_blank">HP® Official Store Deals</a></td></tr><tr></tr></tbody></table></div>
        
        <div style="clear: both;"></div>
    </div>



	</div>

	<div class="right_siderbar" style="<?php if ($_smarty_tpl->tpl_vars['is_capn']->value) {?>display: none;<?php }?>">

        <div style="width:300;">
            <ul class="new_related_list">
                <div class="hdr1">Related Searches</div>
                <div class="nrel"></div>

            </ul>
        </div>
        <?php echo '<script'; ?>
 async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"><?php echo '</script'; ?>
>
<!-- coofinder_300x600 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-3456478881457138"
     data-ad-slot="1749330801"></ins>
<?php echo '<script'; ?>
>
(adsbygoogle = window.adsbygoogle || []).push({});
<?php echo '</script'; ?>
>
	    <div class="width:300px;">
          	<div id="lb_bottom" style="padding:0 10px 0;margin-top:10px;margin-bottom:10px;background-color:white;width:250px;">
          		<div class='section-title scx736 east-goodness right-ads' style="padding-top:10px;">Ads</div>
                        <table id="right_ads_html" class="goodness-list scx830  right-ads ads-table" >

                        </table>

          	</div>

        </div>
	
		

         
	</div>
	<div style="clear:both;"></div>

<div id="ad-params" style="display: none;"   data-kwd="<?php echo $_smarty_tpl->tpl_vars['kwd']->value;?>
" data-stype="<?php echo $_smarty_tpl->tpl_vars['searchType']->value;?>
" data-da="<?php echo $_smarty_tpl->tpl_vars['debug_apiurl']->value;?>
"  ></div>

	
	
</div>


<?php echo '<script'; ?>
 type="text/javascript">
 		var isLoading = false;
        var vid_start=2;


        if( $("#scx93245").length > 0 ){
            var ssp = $("#scx93245").attr("data-uid");
        }else{
            var ssp = $("#default_ssp").attr("data-ssp");
        }


        //getShop();

        $(window).scroll(function () {
           /* if($(window).scrollTop() + getWindowHeights() == $(document).height()) {
                if (!isLoading ) {
                    isLoading = true;
                    $(".img_loader").show();
                    $.post(
                            "<?php echo $_smarty_tpl->tpl_vars['http_url']->value;?>
get_shopping.php",
                            { kwd : '<?php echo urlencode($_smarty_tpl->tpl_vars['kwd']->value);?>
', num : 12, ind : vid_start+2 , mob : 0, ssp:ssp},
                            function(html){
                                $(".img_loader").hide();
                                $("#vid_clear").before(html);
                                isLoading = false;
                                vid_start = vid_start+2;

                            },
                            'html'
                    );
                }
            }*/
        });

        function getShop(){
            if (!isLoading ) {
                isLoading = true;
                $.post(
                        "<?php echo $_smarty_tpl->tpl_vars['http_url']->value;?>
get_shopping.php",
                        { kwd : '<?php echo urlencode($_smarty_tpl->tpl_vars['kwd']->value);?>
', num : 12, ind : 1 , mob : 0, ssp: ssp},
                        function(html){
                            if( html == '' ){
                                $("#noShoppingResults").text("Sorry we don\'t have an products for that search term - please try searching for something else.");
                            }else{
                                $("#vid_clear").before(html);
                                isLoading = false;
                                vid_start = vid_start+2;
                            }

                        },
                        'html'
                );
            }
        }
	 
        function getWindowHeights(){
            var windowHeight = 0;
            if(document.compatMode == "CSS1Compat"){
                windowHeight = document.documentElement.clientHeight;
            }else{
                windowHeight = document.body.clientHeight;
            }
            return windowHeight;
        }



<?php echo '</script'; ?>
>




<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
